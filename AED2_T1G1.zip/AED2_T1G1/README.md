# INF0287 - Algoritmos e Estruturas de Dados 2
# Trabalho-Unidade-1-AED2

Integrantes:

* 202200493 - Arthur Teixeira Perillo
* 202200494 - Arthur Trindade da Silva
* 202103739 - João Felipe Carlos Rodrigues
* 202103744 - Kevin Brunno da Cunha Oliveira
* 202200554 - Rubens Augusto Medeiros Miranda

## Instruções

> **ÁRVORE RUBRO-NEGRA(RED-BLACK):    gcc -Wall RB.c  -o main**
> 
> **ÁRVORE AVL(se encontra na pasta "AVL"): make run**

