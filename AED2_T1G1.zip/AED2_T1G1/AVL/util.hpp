#include <iostream>
#include <stdio.h>
#include <ctype.h>

void menu();
void buscar_palavra();
void inserir_palavras();
void deletar_palavra();